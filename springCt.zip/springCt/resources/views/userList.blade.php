<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="../public/jquery.dataTables.min.css">
    <link rel="stylesheet" href="../public/bootstrap.min.css">
    <title>Users List</title>
</head>

<body>

    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <h1 id="msg"></h1>
                <h1 class="text-center">User List</h1>
                <!-- <table id="userListTable" class="table-bordered table">
                    
                </table> -->

                <table id="userListTable" class="table-bordered table">
                    <thead>
                        <tr>
                            <th>Sr. No</th>
                            <th>Name </th>
                            <th>Phone</th>
                            <th>Email</th>
                            <th>Companies</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @if(!empty($userList))
                        @foreach($userList as $user)

                        <tr id="{{$user->id}}">
                            <td>{{$user->id}}</td>
                            <td>{{ $user->name }}</td>
                            <td>{{ $user->phone }}</td>
                            <td>{{ $user->email }}</td>
                            <td></td>
                            <td><button type="button" class="btn btn-primary" onclick="getCompanyList({{$user->id}})">Assign Company
                            </td>
                        </tr>
                        @endforeach
                        @endif
                    </tbody>
                </table>
                <div class="modal" id="companyListModal">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Assign Company</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>

                            </div>
                            <div class="modal-body">
                                <div class="companyList">
                                    <input type="hidden" id="userId">
                                    <table id="companyListTable" class="table-bordered table">
                                    </table>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-primary" onclick="assingCompany()">Assign</button>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal" id="successModal">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Success</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>

                            </div>
                            <div class="modal-body">
                                <h3 id="successMsg"></h3>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Ok</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    <script src="../public/jquery.min.js"></script>
    <script src="../public/jquery.dataTables.min.js"></script>
    <script src="../public/bootstrap.bundle.min.js"></script>
    <script src="../public/user.js"></script>
    
</body>

</html>
