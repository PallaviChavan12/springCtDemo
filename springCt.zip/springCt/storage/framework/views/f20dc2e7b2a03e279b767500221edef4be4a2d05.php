<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="../public/jquery.dataTables.min.css">
    <link rel="stylesheet" href="../public/bootstrap.min.css">
    <title>Company List</title>
</head>
<body>

    <div class="container">
        <div class="row">
            <div class="col-md-8  col-md-offset-2">
                <h1 id="msg"></h1>
                <h1 class="text-center">Company List</h1>
                <table id="companyListTable" class="table-bordered table">
                    <thead>
                        <tr>
                            <th>Sr. No</th>
                            <th>Name </th>
                            <th>City</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(!empty($companyList)): ?>
                            <?php $__currentLoopData = $companyList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($company->id); ?></td>
                                <td><?php echo e($company->company_name); ?></td>
                                <td><?php echo e($company->city); ?></td>
                                <td><button type="button" class="btn btn-primary" onclick="deleteCompany(<?php echo e($company->id); ?>)">Delete</button>
                                <button type="button" class="btn btn-primary" onclick="getUsersList(<?php echo e($company->id); ?>)">Get Users</button></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
                <div class="modal" id="userListModal">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">User Details</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>

                            </div>
                            <div class="modal-body">
                                <div class="userList">
                                    <input type="hidden" id="userId">
                                    <table id="userListTable" class="table-bordered table">
                                    </table>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="../public/jquery.min.js"></script>
    <script src="../public/jquery.dataTables.min.js"></script>
    <script src="../public/bootstrap.bundle.min.js"></script>
    <script src="../public/company.js"></script>

</body>
</html><?php /**PATH C:\xampp\htdocs\springCt\resources\views/companyList.blade.php ENDPATH**/ ?>