// $(document).ready(function() {
//     $.ajaxSetup({
//         headers: {
//             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
//         }
//     })
//     $.ajax({
//         url: 'users',
//         type: 'get',
//         dataType: 'html',
//         success: function(result) {
//             console.log(result)
//             if (result['userList'] != null) {
//                 $('#userListTable').html('')

//                 if ($.fn.DataTable.isDataTable('#userListTable')) {
//                     $('#userListTable').DataTable().clear().destroy();
//                     $('#userListTable').dataTable().fnDestroy();
//                 }
//                 var str = '';
//                 str += '<thead>'
//                 str += '<tr>'
//                 str += '<th>Sr. No</th>'
//                 str += '<th> Name </th>'
//                 str += '<th>Phone</th>'
//                 str += '<th>Email</th>'
//                 str += '<th>Companies</th>'
//                 str += '</tr>'
//                 str += '</thead>'
//                 str += '<tbody>';

//                 for (i = 0; result['userList'].length > i; i++) {
//                     console.log(result['userList'][i])
//                     str += '<tr id="company_' + result['userList'][i]['id'] + '">'
//                     str += '<td>' + result['userList'][i]['name'] + '</td>';
//                     str += '<td>' + result['userList'][i]['phone'] + '</td>';
//                     str += '<td>' + result['userList'][i]['email'] + '</td>';
//                     str += '<td></td>';

//                     str += '</tr>'
//                 }
//                 str += '</tbody>';
//                 $('#userListTable').append(str);

//                 var table = $('#userListTable').DataTable({
//                     "pageLength": 5,
//                     "lengthMenu": [
//                         [5, 10, 15, -1],
//                         [5, 10, 20, 'All']
//                     ],
//                     "order": [
//                         [1, "asc"]
//                     ],
//                 })
//             }
//         }
//     });
// })

function getCompanyList(userId) {

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    })
    $.ajax({
        url: 'company/listCompanies',
        type: 'get',
        success: function(result) {

            if (result['companyList'] != null) {
                $('#companyListModal').modal('show');
                $('#companyListTable').html('')
                $('#userId').val(userId);

                // $('#companyListTable').dataTable().fnDestroy();
                if ($.fn.DataTable.isDataTable('#companyListTable')) {
                    $('#companyListTable').DataTable().clear().destroy();
                    $('#companyListTable').dataTable().fnDestroy();
                }
                var str = '';
                str += '<thead>'
                str += '<tr>'
                str += '<th>Sr. No</th>'
                str += '<th>Company Name </th>'
                str += '<th>City</th>'
                str += '</tr>'
                str += '</thead>'
                str += '<tbody>';

                for (i = 0; result['companyList'].length > i; i++) {
                    console.log(result['companyList'][i])
                    str += '<tr id="company_' + result['companyList'][i]['id'] + '">'
                    str += '<td><input type="checkbox" name="assign_company_' + result['companyList'][i]['id'] + '" value="' + result['companyList'][i]['id'] + '">';
                    str += '<span class="checkmark"></span></td>';
                    str += '<td>' + result['companyList'][i]['company_name'] + '</td>';
                    str += '<td>' + result['companyList'][i]['city'] + '</td>';
                    str += '</tr>'
                }
                str += '</tbody>';
                $('#companyListTable').append(str);

                var table = $('#companyListTable').DataTable({
                    "pageLength": 5,
                    "lengthMenu": [
                        [5, 10, 15, -1],
                        [5, 10, 20, 'All']
                    ],
                    "order": [
                        [1, "asc"]
                    ],
                })
            }
        }
    });
}

function assingCompany() {
    var companyList = new Array();
    $('#companyListTable').find('input[type=checkbox]:checked').each(
        function() {
            var companyId = $(this).val();
            if (companyId != '') {
                companyList.push({
                    "companyId": companyId
                })
            }
        }
    );
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    })
    $.ajax({
        url: 'user/assignCompanies',
        type: 'POST',
        data: {
            "companyList": companyList,
            "userId": $('#userId').val()
        },
        success: function(result) {
            $('#companyListModal').modal('hide');
            $('#successMsg').html('Companies Assigned Successfully')
            $('#successModal').modal('show');
        }
    });
}