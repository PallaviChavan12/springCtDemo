function deleteCompany(id) {
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    })
    $.ajax({
        url: 'company/deleteCompany',
        type: 'POST',
        data: {
            "id": id
        },
        success: function(result) {
            $('#msg').html('Company deleted successfully');
            $('#msg').css('color', 'green')
            setTimeout(function() {
                $('#msg').hide();
                window.location.reload();
            }, 3000);

        }
    });
}

function getUsersList(companyId) {
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    })
    $.ajax({
        url: 'user/getUsers',
        type: 'post',
        data: {
            "companyId": companyId
        },
        success: function(result) {

            if (result['usersList'] != null) {
                let table1 = document.getElementById('#userListTable');

                // clear first
                if (table1 != null) {
                    table1.clear();
                    table1.destroy();
                }
                $('#userListModal').modal('show');
                $('#userListTable').html('')
                $('#userId').val(userId);

                // $('#userListTable').dataTable().fnDestroy();
                if ($.fn.DataTable.isDataTable('#userListTable')) {
                    $('#userListTable').DataTable().clear().destroy();
                    $('#userListTable').dataTable().fnDestroy();
                }
                var str = '';
                str += '<thead>'
                str += '<tr>'
                str += '<th>Sr. No</th>'
                str += '<th> Name </th>'
                str += '<th>Phone</th>'
                str += '<th>Email</th>'
                str += '</tr>'
                str += '</thead>'
                str += '<tbody>';

                for (i = 0; result['usersList'].length > i; i++) {
                    console.log(result['usersList'][i])
                    str += '<tr id="company_' + result['usersList'][i]['id'] + '">'
                    str += '<td>' + result['usersList'][i]['id'] + '</td>';
                    str += '<td>' + result['usersList'][i]['name'] + '</td>';
                    str += '<td>' + result['usersList'][i]['phone'] + '</td>';
                    str += '<td>' + result['usersList'][i]['email'] + '</td>';
                    str += '</tr>'
                }
                str += '</tbody>';
                $('#userListTable').append(str);

                var table = $('#userListTable').DataTable({
                    "pageLength": 5,
                    destroy: true,
                    "lengthMenu": [
                        [5, 10, 15, -1],
                        [5, 10, 20, 'All']
                    ],
                    "order": [
                        [1, "asc"]
                    ],
                })
            }
        }
    });
}