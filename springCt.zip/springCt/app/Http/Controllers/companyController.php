<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use App\Models\Company;
use DB;

class companyController extends BaseController
{
    public function index()
    {
        $companyList = DB::table('companies')->select('id','company_name','city')->where('is_delete',0)->get();
        return view('companyList',compact('companyList'));
    }

    public function deleteCompany()
    {
        $companyId = $_REQUEST['id'];
        DB::table('companies')->where('id',$companyId)->update(['is_delete'=>1,'deleted_at'=>now()]);
    }

    public function listCompanies()
    {
        $companyList = DB::table('companies')->select('id','company_name','city')->where('is_delete',0)->get();
        return response()->json(['companyList' => $companyList]);
    }
}
