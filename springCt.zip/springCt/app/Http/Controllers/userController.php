<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use DB;

class userController extends BaseController
{
    public function index()
    {
        $userList = DB::table('users')->select('users.id','name','email','phone',\DB::raw("GROUP_CONCAT(companies.company_name) as company_name"))
        ->leftjoin("companies",\DB::raw("FIND_IN_SET(companies.id,users.company_ids)"),">",\DB::raw("'0'"))
        ->groupBy('users.id','name','email','phone','company_name')
        ->get();
        // return response()->json(['userList' => $userList]);

        // $keys = array_flip(array_column(array($userList), 'id'));
        // $newArr = array_map(function($item) use($keys, $userList){ 
        //     $item['company_name'] = $userList[$keys[$item['id']]]['company_name'];
        //     return $item;
        // }, $arr1);
        // print_r($newArr); die;

        // $userArray = [];
        // $cnt = 0;
        // if(!empty($userList))
        // {
        //     foreach($userList as $user)
        //     {
        //         $userArray[$cnt]['id'] = $user['id'];
        //         $userArray[$cnt]['name'] = $user['name'];
        //         $userArray[$cnt]['email'] = $user['email'];
        //         $userArray[$cnt]['phone'] = $user['phone'];
        //         $userArray[$cnt]['company_name'] = $user['company_name'];

        //     }
        // }
        return view('userList',compact('userList'));
    }
    public function assignCompany()
    {
        $company_ids = '';
        if(!empty($_REQUEST['companyList']))
        {
            foreach($_REQUEST['companyList'] as $company)
            {
                $company_ids .= $company['companyId'].',';
            }
            $company_ids = rtrim($company_ids,',');
            DB::table('users')->where('id',$_REQUEST['userId'])->update(['company_ids'=>$company_ids]);

        }
    }

    public function getUsers()
    {
        $companyId = $_REQUEST['companyId'];
        // print_r($companyId);die;
        // \DB::enableQueryLog(); // Enable query log

        $usersList = DB::table('users')->select('users.id','name','email','phone')->whereRaw("find_in_set($companyId,company_ids)")->get();
        // dd(\DB::getQueryLog()); // Show results of log

        // print_r($usersList); die;
        return response()->json(['usersList' => $usersList]);
    }
}
